import rclpy
import math
import sys
import numpy as np

from rclpy.node import Node
from rclpy.qos import QoSProfile
from std_msgs.msg import String
from geometry_msgs.msg import TransformStamped, PoseArray, Pose
from ros2_aruco_interfaces.msg import ArucoMarkers
from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster

class MyNode(Node):
    def __init__(self):
        super().__init__('my_node')
        qos_profile = QoSProfile(depth=10)
        self.aruco_sub_node = self.create_subscription(ArucoMarkers, 'aruco_markers', self.aruco_sub_node_msg, qos_profile)
        self.my_node_pub = self.create_publisher(String, 'my_node_pub', qos_profile)

    def goal_pose_pub_node_msg(self, frame_ids, marker_ids):
        msg = String()
        #msg.data = 'hello'
        msg.data = 'frame_ids = ' + str(frame_ids) + '  marker_ids = ' + str(marker_ids[0])
        self.my_node_pub.publish(msg)

    def aruco_sub_node_msg(self, msg):
        self.get_logger().info('{}'.format(msg.header.frame_id))
        self.get_logger().info('{}'.format(msg.marker_ids))
        self.get_logger().info('{}'.format(msg.poses[0].position))
        self.get_logger().info('{}'.format(msg.poses[0].orientation))
        # 목표지점에 도달하기 전까지 아래함수가 한번만 실행되도록 해야함
        self.goal_pose_pub_node_msg(msg.header.frame_id, msg.marker_ids)


def main(args=None):
    rclpy.init(args=args)
    my_node = MyNode()
    try:
        rclpy.spin(my_node)
    except KeyboardInterrupt:
        my_node.get_logger().info('Keyboard Interrupt (SIGINT)')
    finally:
        my_node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()