def main():
    print('Hi from my_tf_package.')


if __name__ == '__main__':
    main()
