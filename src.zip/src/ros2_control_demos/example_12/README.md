# ros2_control_demo_example_12

   This example shows how to write a simple chainable controller, and how to integrate it properly to have a functional controller chaining.

Find the documentation in [doc/userdoc.rst](doc/userdoc.rst) or on [control.ros.org](https://control.ros.org/master/doc/ros2_control_demos/example_12/doc/userdoc.html).
