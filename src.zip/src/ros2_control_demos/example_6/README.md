# ros2_control_demo_example_6

   The example shows how to implement robot hardware with separate communication to each actuator.

Find the documentation in [doc/userdoc.rst](doc/userdoc.rst) or on [control.ros.org](https://control.ros.org/master/doc/ros2_control_demos/example_6/doc/userdoc.html).
