# ros2_control_demo_example_14

   The example shows how to implement robot hardware with actuators not providing states and with additional sensors.

Find the documentation in [doc/userdoc.rst](doc/userdoc.rst) or on [control.ros.org](https://control.ros.org/master/doc/ros2_control_demos/example_14/doc/userdoc.html).
