# ros2_control_demo_example_10

   *RRBot* - or ''Revolute-Revolute Manipulator Robot'' - with GPIO interfaces.

Find the documentation in [doc/userdoc.rst](doc/userdoc.rst) or on [control.ros.org](https://control.ros.org/master/doc/ros2_control_demos/example_10/doc/userdoc.html).
