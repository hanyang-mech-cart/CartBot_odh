# TB3 Autonomy Package

This core autonomy package has the following
- autonomy node - ros 2 node for core robot autonomy logic
- navigation behaviors - behavior tree nodes

It has a launch file to launch autonomy node

Additional components
- behavior tree design in bt_xml